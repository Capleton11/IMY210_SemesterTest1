docker build -t my-image .

docker run --name express -p 3000:3000 my-image